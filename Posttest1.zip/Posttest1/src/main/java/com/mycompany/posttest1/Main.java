
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // ArrayList untuk menyimpan data kendaraan
        ArrayList<String> namaKendaraan = new ArrayList<>();
        ArrayList<String> jenisKendaraan = new ArrayList<>();
        ArrayList<Double> hargaSewa = new ArrayList<>();

        int pilihan;
        do {
            System.out.println("\n=== SISTEM MANAJEMEN PENYEWAAN KENDARAAN ===");
            System.out.println("1. Tambah Kendaraan");
            System.out.println("2. Lihat Semua Kendaraan");
            System.out.println("3. Update Kendaraan");
            System.out.println("4. Hapus Kendaraan");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = sc.nextInt();
            sc.nextLine(); // buang newline biar input tidak loncat

            switch (pilihan) {
                case 1: // CREATE
                    System.out.print("Masukkan nama kendaraan: ");
                    String nama = sc.nextLine();
                    System.out.print("Masukkan jenis kendaraan (Mobil/Motor): ");
                    String jenis = sc.nextLine();
                    System.out.print("Masukkan harga sewa: ");
                    double harga = sc.nextDouble();

                    namaKendaraan.add(nama);
                    jenisKendaraan.add(jenis);
                    hargaSewa.add(harga);

                    System.out.println("✅ Kendaraan berhasil ditambahkan!");
                    break;

                case 2: // READ
                    if (namaKendaraan.isEmpty()) {
                        System.out.println("⚠ Belum ada data kendaraan.");
                    } else {
                        System.out.println("\n=== Daftar Kendaraan ===");
                        for (int i = 0; i < namaKendaraan.size(); i++) {
                            System.out.println((i+1) + ". " +
                                    "Nama: " + namaKendaraan.get(i) +
                                    " | Jenis: " + jenisKendaraan.get(i) +
                                    " | Harga: Rp" + hargaSewa.get(i));
                        }
                    }
                    break;

                case 3: // UPDATE
                    if (namaKendaraan.isEmpty()) {
                        System.out.println("⚠ Belum ada data kendaraan.");
                        break;
                    }

                    System.out.println("\nPilih kendaraan yang ingin diupdate:");
                    for (int i = 0; i < namaKendaraan.size(); i++) {
                        System.out.println((i+1) + ". " + namaKendaraan.get(i));
                    }
                    System.out.print("Masukkan nomor kendaraan: ");
                    int idxUpdate = sc.nextInt() - 1;
                    sc.nextLine();

                    if (idxUpdate >= 0 && idxUpdate < namaKendaraan.size()) {
                        System.out.print("Nama baru: ");
                        namaKendaraan.set(idxUpdate, sc.nextLine());
                        System.out.print("Jenis baru: ");
                        jenisKendaraan.set(idxUpdate, sc.nextLine());
                        System.out.print("Harga sewa baru: ");
                        hargaSewa.set(idxUpdate, sc.nextDouble());

                        System.out.println("✅ Data kendaraan berhasil diperbarui!");
                    } else {
                        System.out.println("⚠ Nomor tidak valid.");
                    }
                    break;

                case 4: // DELETE
                    if (namaKendaraan.isEmpty()) {
                        System.out.println("⚠ Belum ada data kendaraan.");
                        break;
                    }

                    System.out.println("\nPilih kendaraan yang ingin dihapus:");
                    for (int i = 0; i < namaKendaraan.size(); i++) {
                        System.out.println((i+1) + ". " + namaKendaraan.get(i));
                    }
                    System.out.print("Masukkan nomor kendaraan: ");
                    int idxHapus = sc.nextInt() - 1;

                    if (idxHapus >= 0 && idxHapus < namaKendaraan.size()) {
                        namaKendaraan.remove(idxHapus);
                        jenisKendaraan.remove(idxHapus);
                        hargaSewa.remove(idxHapus);
                        System.out.println("✅ Kendaraan berhasil dihapus!");
                    } else {
                        System.out.println("⚠ Nomor tidak valid.");
                    }
                    break;

                case 5:
                    System.out.println("👋 Terima kasih telah menggunakan program ini!");
                    break;

                default:
                    System.out.println("⚠ Pilihan tidak valid.");
            }
        } while (pilihan != 5);

        sc.close();
    }
}
